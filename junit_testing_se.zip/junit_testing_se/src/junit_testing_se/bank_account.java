/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package junit_testing_se;

import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;

/**
 *
 * @author jatin jangir
 */
public class bank_account {
	String name, actype;
	int accNo, bal, amt=0;
        List<String> actypes=new ArrayList<String>();
	public bank_account(){
            actypes.add("saving");
            actypes.add("current");
            actypes.add("buisness");
        }
        @Test
        boolean setname(String n){
            this.name = n;
            return true;    
	}
        @Test
        boolean setbalance(int n){
            this.bal = n;
            return true;    
	}
        @Test
        boolean setaccount(String n){
            if(actypes.contains(n)==false)return false;
            this.actype = n;
            return true;    
	}
        @Test
        boolean setaccno(int n){
            if(n<0)return false;
            this.accNo = n;
            return true;    
	}
        @Test
	int deposit(int amt) {
		
		if (amt < 0) {
			System.out.println("Invalid Amount");
			return -1;
		}
		bal = bal + amt;
		return 0;
	}
        @Test
	int withdraw(int amt) {
		System.out.println("Your Balance=" + bal);
		if (bal < amt) {
			System.out.println("Not sufficient balance.");
			return -1;
		}
		if (amt < 0) {
			System.out.println("Invalid Amount");
			return -1;
		}
		bal = bal - amt;
		return bal;
	}
        @Test
	void display() {
		System.out.println("Name:" + name);
		System.out.println("Account No:" + accNo);
		System.out.println("Balance:" + bal);

	}
        @Test
	void dbal() {
		System.out.println("Balance:" + bal);
	}

}
