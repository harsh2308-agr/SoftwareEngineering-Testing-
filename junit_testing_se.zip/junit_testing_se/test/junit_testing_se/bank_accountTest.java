/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package junit_testing_se;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author jatin jangir
 */
public class bank_accountTest {
    public bank_accountTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }

    /**
     * Test of setname method, of class bank_account.
     */
    @Test
    public void testSetname() {
        System.out.println("setname");
        // base case
        String n = "jatin";
        bank_account instance = new bank_account();
        boolean expResult = true;
        boolean result = instance.setname(n);
        assertEquals(expResult, result);
         // boundary case
         n = "";
        instance = new bank_account();
        expResult = false;
        result = instance.setname(n);
        assertEquals(expResult, result);
    }

    /**
     * Test of setbalance method, of class bank_account.
     */
    @Test
    public void testSetbalance() {
        System.out.println("setbalance");
        int n = 100;
        bank_account instance = new bank_account();
        boolean expResult = true;
        boolean result = instance.setbalance(n);
        assertEquals(expResult, result);
        
        n = -1;
        instance = new bank_account();
        expResult = false;
        result = instance.setbalance(n);
        assertEquals(expResult, result);
    }

    /**
     * Test of setaccount method, of class bank_account.
     */
    @Test
    public void testSetaccount() {
        System.out.println("setaccount");
        String n = "saving";
        bank_account instance = new bank_account();
        boolean expResult = true;
        boolean result = instance.setaccount(n);
        assertEquals(expResult, result);
        
        n = "oooooo";
        instance = new bank_account();
        expResult = false;
        result = instance.setaccount(n);
        assertEquals(expResult, result);
    }

    /**
     * Test of setaccno method, of class bank_account.
     */
    @Test
    public void testSetaccno() {
        System.out.println("setaccno");
        int n = 987;
        bank_account instance = new bank_account();
        boolean expResult =true;
        boolean result = instance.setaccno(n);
        assertEquals(expResult, result);
        
        n = -1;
        instance = new bank_account();
        expResult =false;
        result = instance.setaccno(n);
        assertEquals(expResult, result);
    }

    /**
     * Test of deposit method, of class bank_account.
     */
    @Test
    public void testDeposit() {
        System.out.println("deposit");
        int n = 987;
        bank_account instance = new bank_account();
        instance.bal=1000;
        int expResult =0;
        int result = instance.deposit(n);
        assertEquals(expResult, result);
        
        n = -987;
        instance = new bank_account();
        instance.bal=1000;
        expResult =-1;
        result = instance.deposit(n);
        assertEquals(expResult, result);
    }

    /**
     * Test of withdraw method, of class bank_account.
     */
    @Test
    public void testWithdraw() {
        System.out.println("withdraw");
        int amt = 100;
        bank_account instance = new bank_account();
        instance.bal=100;
        int expResult = 0;
        int result = instance.withdraw(amt);
        assertEquals(expResult, result);
        
        amt = 1000;
        instance = new bank_account();
        instance.bal=100;
        expResult = -1;
        result = instance.withdraw(amt);
        assertEquals(expResult, result);
    }

    /**
     * Test of display method, of class bank_account.
     */
    @Test
    public void testDisplay() {
        System.out.println("display");
        bank_account instance = new bank_account();
        instance.display();
    }

    /**
     * Test of dbal method, of class bank_account.
     */
    @Test
    public void testDbal() {
        System.out.println("dbal");
        bank_account instance = new bank_account();
        instance.dbal();
    }
    
}
