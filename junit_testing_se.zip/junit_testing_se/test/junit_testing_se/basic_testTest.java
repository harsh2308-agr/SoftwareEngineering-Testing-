/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package junit_testing_se;

import org.junit.Test;
import org.junit.Assert;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author jatin jangir
 */
public class basic_testTest {
    //create object of our class
    basic_test object;
    int[] arr={8,9,5,6,7,3,4,1,2};
    int[] expected={1,2,3,4,5,6,7,8,9};
    
    public basic_testTest() {
         object=new basic_test();
    }
    
    @BeforeEach
    public void setUp() {
        // initiallize object
        object=new basic_test();
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of insertionSort method, of class basic_test.
     */
    @Test
    public void testInsertionSort() {
        //create array
        
        int[] arr_out=object.insertionSort(arr);
       
         Assert.assertArrayEquals(expected, arr_out);
        
    }

    /**
     * Test of bubbleSort method, of class basic_test.
     */
    @Test
    public void testBubbleSort() {
        int[]arrout=object.bubbleSort(arr);
        Assert.assertArrayEquals(expected, arrout);
    }

    /**
     * Test of selectionSort method, of class basic_test.
     */
    @Test
    public void testSelectionSort() {
        int[] arrout=object.selectionSort(arr);
         Assert.assertArrayEquals(expected, arrout);
    }

    /**
     * Test of builtInSort method, of class basic_test.
     */
    @Test
    public void testBuiltInSort() {
        int[] arrout=object.builtInSort(arr);
        Assert.assertArrayEquals(expected, arrout);
        
    }
    
}
