/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package junit_testing_se;

import java.util.Arrays;
import org.junit.jupiter.api.Test;

/**
 *
 * @author jatin jangir
 */
public class basic_test {
    // we are creating some methods for testing
   
    public int[] insertionSort(int[] arr) {
        for (int x = 1; x < arr.length; x++) {
            int current = arr[x];
            int y = x - 1;
            while(y >= 0 && current < arr[y]) {
                arr[y+1] = arr[y];
                y--;
            }
            arr[y+1] = current;
        }
        return arr;
    }
    public int[] bubbleSort(int[] arr) {
        int n = arr.length;
        int tmp = 0;
        for(int x=0; x < n; x++){
            for(int y=1; y < (n-x); y++){
                if(arr[y-1] > arr[y]){
                    //swap elements
                    tmp = arr[y-1];
                    arr[y-1] = arr[y];
                    arr[y] = tmp;
                }
            }
        }
        return arr;
    }
    public int[] selectionSort(int[] arr){
        for (int x = 0; x < arr.length - 1; x++)
        {
            int indx = x;
            for (int y = x + 1; y < arr.length; y++){
                if (arr[y] < arr[indx]){
                    indx = y;
                }
            }
            int smallNumber = arr[indx];
            arr[indx] = arr[x];
            arr[x] = smallNumber;
        }
        return arr;
    }
    public int[] builtInSort(int[] arr){
        Arrays.sort(arr);
        return arr;
    }
}
